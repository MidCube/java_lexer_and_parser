package main.java.cig23.cam.ac.uk.SummerCompiler;

public enum Terminals {

    LBracket, Rbracket, Number, Plus, Minus, Mult, Cos, Bang, Finish, E, A, B, C, D, F, S;
}
