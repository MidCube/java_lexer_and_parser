package main.java.cig23.cam.ac.uk.SummerCompiler;

public enum ShiftReduce {
    Shift, Reduce, Accept;
}